ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local airdropActive = false
local airdropLocation = nil

function CreateAirdrop()
    local location = Config.Locations[math.random(1, #Config.Locations)]
    airdropLocation = location
    airdropActive = true

    local money = math.random(Config.Rewards.money.min, Config.Rewards.money.max)
    local weapon = Config.Rewards.weapons[math.random(1, #Config.Rewards.weapons)]

    TriggerClientEvent('airdrop:spawnCrate', -1, location, money, weapon)
    TriggerClientEvent('chat:addMessage', -1, {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(0, 0, 0, 0.6); border-radius: 3px;"><i class="fas fa-parachute-box"></i> Airdrop byl shozen na n�hodn� lokaci!</div>',
        args = {}
    })
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.AirdropInterval)
        if not airdropActive then
            CreateAirdrop()
        end
    end
end)

RegisterServerEvent('airdrop:crateLooted')
AddEventHandler('airdrop:crateLooted', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local money = math.random(Config.Rewards.money.min, Config.Rewards.money.max)
    local weaponData = Config.Rewards.weapons[math.random(1, #Config.Rewards.weapons)]

    xPlayer.addMoney(money)
    xPlayer.addWeapon(weaponData.weapon, weaponData.ammo)

    TriggerClientEvent('chat:addMessage', source, {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(0, 128, 0, 0.6); border-radius: 3px;"><i class="fas fa-gift"></i> Získal jsi airdrop!</div>',
        args = {}
    })

    airdropActive = false
    airdropLocation = nil
    TriggerClientEvent('airdrop:removeCrate', -1)
end)