local crateObject = nil
local crateLocation = nil
local blip = nil

function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x,y,z, 0)
    DrawText(0.0, 0.0)
    local factor = (string.len(text)) / 370
    DrawRect(0.0, 0.0+0.0125, 0.017+ factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

RegisterNetEvent('airdrop:spawnCrate')
AddEventHandler('airdrop:spawnCrate', function(location, money, weapon)
    local model = GetHashKey('prop_box_ammo04a')
    RequestModel(model)
    while not HasModelLoaded(model) do
        Citizen.Wait(1)
    end

    crateObject = CreateObject(model, location.x, location.y, location.z, true, true, true)
    PlaceObjectOnGroundProperly(crateObject)
    crateLocation = location

    blip = AddBlipForCoord(location.x, location.y, location.z)
    SetBlipSprite(blip, 478)
    SetBlipColour(blip, 3)
    SetBlipScale(blip, 1.5)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Airdrop")
    EndTextCommandSetBlipName(blip)
end)

RegisterNetEvent('airdrop:removeCrate')
AddEventHandler('airdrop:removeCrate', function()
    if crateObject then
        DeleteObject(crateObject)
        crateObject = nil
    end
    if blip then
        RemoveBlip(blip)
        blip = nil
    end
    crateLocation = nil
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if crateLocation then
            local playerPos = GetEntityCoords(PlayerPedId())
            local distance = GetDistanceBetweenCoords(playerPos, crateLocation.x, crateLocation.y, crateLocation.z, true)

            if distance < 2.0 then
                DrawText3D(crateLocation.x, crateLocation.y, crateLocation.z + 1.0, '[E] Vzít Airdrop')
                if IsControlJustReleased(0, 38) then
                    TriggerServerEvent('airdrop:crateLooted')
                end
            end
        end
    end
end)