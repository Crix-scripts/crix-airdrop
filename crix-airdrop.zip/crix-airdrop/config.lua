Config = {}

Config.AirdropInterval = 5 * 60 * 1000 -- 5 minut�ch nebo millisekund�ch

Config.Rewards = {
    money = {min = 1000, max = 5000},
    weapons = {
        {weapon = 'WEAPON_PISTOL', ammo = 100},
        {weapon = 'WEAPON_SMG', ammo = 120},
        {weapon = 'WEAPON_CARBINERIFLE', ammo = 150}
    }
}

Config.Locations = {
    {x = 119.9, y = 6626.2, z = 31.8},
    {x = 2490.4, y = 4970.7, z = 46.6},
    {x = -1037.0, y = -2733.5, z = 20.2},
    {x = 1692.8, y = 3250.9, z = 41.2}
}