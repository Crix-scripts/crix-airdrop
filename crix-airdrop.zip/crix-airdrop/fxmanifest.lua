fx_version 'cerulean'
game 'gta5'

author 'crix'
description 'Military Airdrop script'
version '1.0.0'

server_scripts {
    'server/main.lua',
    'config.lua'
}

client_scripts {
    'client/main.lua',
    'config.lua'
}